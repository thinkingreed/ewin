#![allow(clippy::needless_return, clippy::iter_nth_zero, clippy::type_complexity)]
#[macro_use]
extern crate downcast;
extern crate ewin_com;

pub mod model;
pub mod prom;
pub mod prom_base;
pub mod util;
pub mod prom_trait {
    pub mod cont_trait;
    pub mod main_trait;
}
pub mod each {
    pub mod enc_nl;
    pub mod grep;
    pub mod grep_result;
    pub mod greping;
    pub mod move_row;
    pub mod open_file;
    pub mod replace;
    pub mod save_confirm;
    pub mod save_forced;
    pub mod save_new_file;
    pub mod search;
    pub mod watch_file;
}
pub mod cont {
    pub mod parts {
        pub mod choice;
        pub mod file_list;
        pub mod info;
        pub mod input_area;
        pub mod key_desc;
        pub mod path_comp;
        pub mod pulldown;
        pub mod search_opt;
    }
    pub mod cur;
    pub mod edit;
    pub mod mouse;
    pub mod proc_edit;
    pub mod select;
    pub mod un_redo;
}

#![allow(clippy::needless_return, clippy::iter_nth_zero, clippy::type_complexity)]

pub mod def;
pub mod model;
